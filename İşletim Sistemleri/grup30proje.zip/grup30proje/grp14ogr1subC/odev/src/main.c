/**
 * @file  main.c
 * @course				İşletim Sistemleri
 * @assignment			Proje
 * @group				30
 * @author G171210014	Aslıhan Çetiner
 * @author G171210551   Recep İlyasoğlu
 * @author G171210089	Neva Emel İşler
 * @author G171210044	Nisanur Karatepe
 * @author G171210095   Zeynep Sena Nur Tekin
 */



#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>

#include <errno.h>

int arkaPlandaCalisanProsesSayisi;

void handler(int signum)
{
	int wStatus;
	int pid;
	while((pid = waitpid(-1, &wStatus, WNOHANG)) > 0)
	{
		//process'in geri dönüş değerini alır
		int ret = WEXITSTATUS(wStatus);
		printf("[%d] retval: %d\n", pid, ret);
		fflush(stdout);
		//Arkaplan'da calisan process durdurulduğuna göre değeri bir azaltılabilir.
		arkaPlandaCalisanProsesSayisi--;
	}
	return;
}

#define KOMUT_BOYUTU 1024

int main()
{
	//kullanıcıdan girdi alınır
	char girdi[KOMUT_BOYUTU];
	char* komut_parcasi;
	char* komut_parcalar[3][16];
	char giriseYonlendirilenDosya[64];
	int giriseYonlendirmefd;
	int girisYonlendir;
	char cikisaYonlendirilenDosya[64];
	int cikisaYonlendirmefd;
	int cikisYonlendir;
	int pipeVarMi;
	int pipeSayisi;
	int hata;
	int arkaPlandaCalistir;
	int wStatus;

	struct sigaction act;
	act.sa_handler = handler;
	act.sa_flags = SA_RESTART;

	sigaction(SIGCHLD, &act, NULL);

	int program_devam = 1;
	while(program_devam)
	{
		//komut_parcalar[0] = NULL;
		girisYonlendir = 0;
		cikisYonlendir = 0;
		pipeVarMi = 0;
		pipeSayisi = 0;
		hata = 0;
		arkaPlandaCalistir = 0;
		printf(">");
		fflush(stdout);	//prompt'ın hemen yazılmasından emin olmak için
		fgets(girdi, KOMUT_BOYUTU, stdin);
		//Alınan girdinin sonundaki alt satır karakteri kaldırılır
		for(int i = 0; i < strlen(girdi); i++)
		{
			if(girdi[i] == '\n')
			{
				girdi[i] = '\0';
			}
		}
		//Eğer girilen komut quit ise, programdan çık
		if(strcmp(girdi, "quit") == 0)
		{
			program_devam = 0;
			while(arkaPlandaCalisanProsesSayisi > 0);
			break;
		}
		//komut parse edilir
		//girilen komut kadar döngüde dön, böylece komutun her bir karakterinde gez
		int i = 0;
		int komutNo = 0;
		for(komut_parcasi = strtok(girdi, " "); komut_parcasi != NULL; komut_parcasi = strtok(NULL, " "))
		{
			if(strcmp(komut_parcasi, "<") == 0)
			{
				// < işaretinden sonraki yazıyı girişe yönlendirilecek olan dosya olarak kabul edilir
				strcpy(giriseYonlendirilenDosya, strtok(NULL, " "));
				//girişe yöyönlendirilecek olan dosya okuma modunda açılır
				giriseYonlendirmefd = open(giriseYonlendirilenDosya, O_RDONLY);
				//açma işlemi başaralı olduysa girisYonlendir 1 yapılır
				if(giriseYonlendirmefd >= 0)
				{
					girisYonlendir = 1;
				}
				else
				{
					printf("%s giris dosyasi bulunamadi\n", giriseYonlendirilenDosya);
					hata = 1;
				}
				continue;
			}
			if(strcmp(komut_parcasi, ">") == 0)
			{
				// > işaretinden sonraki yazıyı çıkışa yönlendirilecek olan dosya olarak kabul edilir
				strcpy(cikisaYonlendirilenDosya, strtok(NULL, " "));
				//çıkışa yöyönlendirilecek olan dosya yazma ve yoksa oluşturma modunda açılır
				cikisaYonlendirmefd = open(cikisaYonlendirilenDosya, O_WRONLY | O_CREAT, 0666);
				//açma işlemi başaralı olduysa cikisYonlendir 1 yapılır
				if(cikisaYonlendirmefd >= 0)
					cikisYonlendir = 1;
				continue;
			}
			if(strcmp(komut_parcasi, "&") == 0)
			{
				arkaPlandaCalistir = 1;
				continue;
			}
			if(strcmp(komut_parcasi, "|") == 0)
			{
				komut_parcalar[komutNo][i] = '\0';
				pipeVarMi = 1;
				pipeSayisi++;
				komutNo++;
				i = 0;
				continue;
			}

			komut_parcalar[komutNo][i] = komut_parcasi;
			i++;
		}
		komut_parcalar[komutNo][i] = '\0';

		//Çoçuk proses oluşturulur

		if(pipeVarMi == 0)
		{
			int forkDonus = fork();
			if(forkDonus < 0)
			{
				fprintf(stderr, "fork yapilamadi\n");
			}
			else if(forkDonus > 0)	//Ebeveyn proses
			{
				//Çoçuğun dönmesini bekle
				if(arkaPlandaCalistir == 0)
				{
					waitpid(forkDonus, &wStatus, 0);
				}
				else if(arkaPlandaCalistir == 1)
				{
					arkaPlandaCalisanProsesSayisi++;
					arkaPlandaCalistir = 0;
				}
			}
			else if(forkDonus == 0)	//Çoçuk proses
			{
				if(komut_parcalar[0][0] != NULL && hata != 1)
				{
					if(girisYonlendir == 1)
						dup2(giriseYonlendirmefd, 0);
					if(cikisYonlendir == 1)
						dup2(cikisaYonlendirmefd, 1);
					execvp(komut_parcalar[0][0], komut_parcalar[0]);
					perror("exec_hata");
				}
				exit(1);
			}
		}
		else if(pipeVarMi == 1)
		{
			//File descriptorlar dizisi oluşturulur
			int fdler[2*pipeSayisi];
			//File descriptorlar initialize edilir
			for(int i = 0; i < pipeSayisi; i++)
			{
				pipe(&fdler[i*2]);
			}
			int komutSayisi = pipeSayisi + 1;

			if(komutSayisi == 2)
			{
				int forkDonus = fork();
				if(forkDonus == 0)
				{
					dup2(fdler[1], 1);

					close(fdler[0]);

					execvp(komut_parcalar[0][0], komut_parcalar[0]);
				}
				else
				{

					int forkDonus = fork();
					if(forkDonus == 0)
					{
						dup2(fdler[0], 0);
						close(fdler[1]);

						execvp(komut_parcalar[1][0], komut_parcalar[1]);
					}

				}
				wait(NULL);
			}
			else if(komutSayisi == 3)
			{

				int forkDonus = fork();
				if(forkDonus == 0)
				{
					dup2(fdler[1], 1);

					for(int i = 0; i < pipeSayisi*2; i++)
					{
						close(fdler[i]);
					}

					execvp(komut_parcalar[0][0], komut_parcalar[0]);
				}
				else
				{
					int forkDonus = fork();
					if(forkDonus == 0)
					{
						dup2(fdler[0], 0);
						dup2(fdler[3], 1);

						for(int i = 0; i < pipeSayisi*2; i++)
						{
							close(fdler[i]);
						}

						execvp(komut_parcalar[1][0], komut_parcalar[1]);
					}
					else
					{
						int forkDonus = fork();
						if(forkDonus == 0)
						{
							dup2(fdler[2], 0);

							for(int i = 0; i < pipeSayisi*2; i++)
							{
								close(fdler[i]);
							}

							execvp(komut_parcalar[2][0], komut_parcalar[2]);
						}
					}
				}
				for(int i = 0; i < pipeSayisi*2; i++)
				{
					close(fdler[i]);
				}

				for(int i = 0; i < komutSayisi; i++)
				{
					wait(NULL);
				}
			}

		}
	}

}
