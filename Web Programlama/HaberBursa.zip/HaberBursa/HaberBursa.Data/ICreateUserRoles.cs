﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HaberBursa.Data
{
    public interface ICreateUserRoles
    {
        void AddUserRole();
    }
}
